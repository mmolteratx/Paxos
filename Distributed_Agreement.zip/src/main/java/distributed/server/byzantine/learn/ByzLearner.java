package distributed.server.byzantine.learn;

import distributed.server.paxos.learn.Learner;

/**
 * Byzantine learner
 */
public class ByzLearner extends Learner
{
}
