package distributed.server.pojos;

import lombok.Data;

@Data
public abstract class Value
{
    int id;
    String value;
}
