package distributed.server.pojos;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class ProposedValue extends Value
{
}
