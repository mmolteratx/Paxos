package distributed;

public class DistributedAgreementTest
{

}